package springwork.controller;
import qofd.Dao.*;
import qofd.Models.*;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	@RequestMapping("/")
	public ModelAndView HomePage()  {
		
		ModelAndView mav = new ModelAndView("HomePage");
		
		return mav;
	}
	
	@RequestMapping(value="/", method = RequestMethod.POST)
	public ModelAndView LoginPage(HttpServletRequest request) throws SQLException {
		ModelAndView mav = new ModelAndView("HomePage");
		UserDAO uDAO = new UserDAO();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		User user = uDAO.loginUser(email, password);
		
		
		if(user != null)
			request.getSession().setAttribute("user", user);
		else
			mav.addObject("message", "Log In Failed");
			
		
		return mav;
	}
	
	
	@RequestMapping("/DashBoard")
	public ModelAndView DashBoard()  {
		
		ModelAndView mav = new ModelAndView("DashBoard");
		
		return mav;
	}

}




